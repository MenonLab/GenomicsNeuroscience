## ----Setup, include = FALSE---------------------------------------------------------------------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----Libraries, message = FALSE-----------------------------------------------------------------------------------------------------------------------
library(SpatialExperiment)
library(STexampleData)
library(BayesSpace)
library(ggspavis)
library(scater)
library(scran)
library(bluster)
library(pheatmap)
library(gridExtra)

spe <- Visium_humanDLPFC()


## ----Dataset------------------------------------------------------------------------------------------------------------------------------------------
spe
head(colData(spe))
head(rowData(spe))

plotVisium(spe, fill = "ground_truth", highlight = "in_tissue")
table(spe$in_tissue)

spe <- spe[, colData(spe)$in_tissue == 1]
dim(spe)

MOBP <- rowData(spe)$gene_name == "MOBP"
spe$MOBP <- log2(assay(spe)[MOBP, ] + 1)
plotVisium(spe, fill = "MOBP", palette = "red")


## ----QualityControl-----------------------------------------------------------------------------------------------------------------------------------
mito <- grepl("(^MT-)|(^mt-)", rowData(spe)$gene_name)
table(mito)

spe <- addPerCellQC(spe, subsets = list(mito = mito))
head(colData(spe))

plotQC(spe, type = "scatter", 
       metric_x = "cell_count", metric_y = "sum")

plotQC(spe, type = "scatter", 
       metric_x = "sum", metric_y = "detected")

hist(spe$subsets_mito_percent)

spe$logSum <- log2(spe$sum)
plotSpots(spe, annotate ="logSum", size = 1)

qc_umi <- spe$sum < 300
qc_detected <- spe$detected < 200
qc_mito <- spe$subsets_mito_percent > 30
qc_cell_count <- spe$cell_count > 20

spe$lowQuality <- qc_umi | qc_detected | qc_mito | qc_cell_count
plotSpots(spe, annotate = "lowQuality", size = 1)
sum(spe$lowQuality)
spe <- spe[, !spe$lowQuality]


## ----Normalization------------------------------------------------------------------------------------------------------------------------------------
spe <- computeLibraryFactors(spe)
hist(spe$sizeFactor)
spe <- logNormCounts(spe)
assayNames(spe)


## ----VariableGenes------------------------------------------------------------------------------------------------------------------------------------
dec <- modelGeneVar(spe)
fit <- metadata(dec)
plot(fit$mean, fit$var,
     xlab = "Mean of log-expression",
     ylab = "Variance of log-expression")
curve(fit$trend(x), col = "dodgerblue", add = TRUE, lwd = 2)

topHvgs <- getTopHVGs(dec, n = 2000)


## ----DimensionReduction-------------------------------------------------------------------------------------------------------------------------------
set.seed(123)
spe <- runPCA(spe, subset_row = topHvgs)

set.seed(123)
spe <- runUMAP(spe, dimred = "PCA")

reducedDimNames(spe)

plotDimRed(spe, type = "PCA", annotate = "ground_truth")
plotDimRed(spe, type = "UMAP", annotate = "ground_truth")


## ----Clustering---------------------------------------------------------------------------------------------------------------------------------------
d <- 15

set.seed(123)
spe$Walktrap <- clusterRows(reducedDim(spe)[, 1:d],
  BLUSPARAM=NNGraphParam(cluster.fun = "walktrap", k = 20))

set.seed(123)
spe$Louvain <- clusterRows(reducedDim(spe)[, 1:d],
  BLUSPARAM=NNGraphParam(cluster.fun = "louvain", k = 20,
  cluster.args=list(resolution = 1)))


spe <- spatialPreprocess(spe, platform="Visium", skip.PCA=TRUE)
colData(spe)$row <- colData(spe)$array_row
colData(spe)$col <- colData(spe)$array_col

# This takes ~5min
set.seed(123)
spe <- spatialCluster(spe, q = 7, d = d, platform = "Visium", gamma = 3,
                      nrep = 11000, burn.in = 1000, save.chain = FALSE)
spe$BayesSpace <- factor(spe$spatial.cluster)


grid.arrange(plotSpots(spe, annotate = "Walktrap") + ggtitle(""),
             plotSpots(spe, annotate = "Louvain") + ggtitle(""),
             plotSpots(spe, annotate = "BayesSpace") + ggtitle(""),
             plotSpots(spe, annotate = "ground_truth") + ggtitle(""))

grid.arrange(plotDimRed(spe, type = "UMAP", annotate = "BayesSpace") +
                 ggtitle("BayesSpace") + theme(legend.pos = "none"),
             plotDimRed(spe, type = "UMAP", annotate = "ground_truth") +
                 ggtitle("Ground truth") + theme(legend.pos = "none"),
             nrow = 1)


## ----MarkerGenes--------------------------------------------------------------------------------------------------------------------------------------
rownames(spe) <- rowData(spe)$gene_name
markers <- findMarkers(spe, groups = spe$BayesSpace,
                       test = "binom", direction = "up")

cluster4 <- markers[["4"]]
logFCs <- getMarkerEffects(cluster4[cluster4$Top <= 5, ])

pheatmap(logFCs)


## ----AdjRandIndex-------------------------------------------------------------------------------------------------------------------------------------
adjRandIndex <- function (x, y) {
  stopifnot(length(x) == length(y))
  tab <- table(x,y)
  if (all(dim(tab) == c(1,1))) return(1)
  a <- sum(choose(tab, 2))
  b <- sum(choose(rowSums(tab), 2)) - a
  c <- sum(choose(colSums(tab), 2)) - a
  d <- choose(sum(tab), 2) - a - b - c
  ARI <- (a - (a + b) * (a + c)/(a + b + c + d)) /
    ((a + b + a + c)/2 - (a + b) * (a + c)/(a + b + c + d))
  return(ARI)
}


## ----SessionInfo--------------------------------------------------------------------------------------------------------------------------------------
sessionInfo()

